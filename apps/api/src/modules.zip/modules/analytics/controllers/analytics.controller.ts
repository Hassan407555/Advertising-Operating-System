import {
  Controller,
  Get,
  Param,
  Query,
} from '@nestjs/common';

import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';

import { AnalyticsService } from '../services/analytics.service';

import { AnalyticsQueryDto } from '../dto/analytics-query.dto';
import { AnalyticsResponseDto } from '../dto/analytics-response.dto';

import { CurrentUser } from '../../auth/decorators/current-user.decorator';
import type { JwtPayload } from '../../auth/interfaces/jwt-payload.interface';

@ApiTags('Analytics')
@ApiBearerAuth()
@Controller('analytics')
export class AnalyticsController {
  constructor(
    private readonly analyticsService: AnalyticsService,
  ) {}

  @Get()
  @ApiOperation({
    summary: 'Retrieve analytics snapshots',
  })
  @ApiResponse({
    status: 200,
    description: 'Analytics retrieved successfully.',
  })
  findAll(
    @Query() query: AnalyticsQueryDto,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.findAll(
      query,
      currentUser,
    );
  }

  @Get(':id')
  @ApiOperation({
    summary: 'Retrieve analytics snapshot',
  })
  @ApiResponse({
    status: 200,
    type: AnalyticsResponseDto,
  })
  findOne(
    @Param('id') id: string,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.findOne(
      id,
      currentUser,
    );
  }

  @Get('summary')
  @ApiOperation({
    summary: 'Analytics summary',
  })
  getSummary(
    @Query() query: AnalyticsQueryDto,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.getSummary(
      query,
      currentUser,
    );
  }

  @Get('timeseries')
  @ApiOperation({
    summary: 'Analytics time series',
  })
  getTimeSeries(
    @Query() query: AnalyticsQueryDto,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.getTimeSeries(
      query,
      currentUser,
    );
  }
    @Get('breakdown/campaigns')
  @ApiOperation({
    summary: 'Campaign analytics breakdown',
  })
  getCampaignBreakdown(
    @Query() query: AnalyticsQueryDto,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.getBreakdownByCampaign(
      query,
      currentUser,
    );
  }

  @Get('breakdown/adsets')
  @ApiOperation({
    summary: 'Ad Set analytics breakdown',
  })
  getAdSetBreakdown(
    @Query() query: AnalyticsQueryDto,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.getBreakdownByAdSet(
      query,
      currentUser,
    );
  }

  @Get('breakdown/ads')
  @ApiOperation({
    summary: 'Ad analytics breakdown',
  })
  getAdBreakdown(
    @Query() query: AnalyticsQueryDto,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.getBreakdownByAd(
      query,
      currentUser,
    );
  }

  @Get('breakdown/creatives')
  @ApiOperation({
    summary: 'Creative analytics breakdown',
  })
  getCreativeBreakdown(
    @Query() query: AnalyticsQueryDto,
    @CurrentUser() currentUser: JwtPayload,
  ) {
    return this.analyticsService.getBreakdownByCreative(
      query,
      currentUser,
    );
  }
}