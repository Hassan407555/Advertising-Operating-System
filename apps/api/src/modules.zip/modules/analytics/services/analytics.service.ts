import {
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';

import {
  AnalyticsLevel,
  PlatformType,
  Prisma,
} from '@prisma/client';

import { PaginatedResponseDto } from '../../../common/dto/pagination.dto';

import { PrismaService } from '../../../infrastructure/prisma/prisma.service';

import type { JwtPayload } from '../../auth/interfaces/jwt-payload.interface';

import {
  ANALYTICS_INCLUDE,
  ANALYTICS_SORT_FIELDS,
  DEFAULT_SORT_BY,
  type AnalyticsSortField,
} from '../constants/analytics.constants';

import { AnalyticsQueryDto } from '../dto/analytics-query.dto';
import { AnalyticsResponseDto } from '../dto/analytics-response.dto';
import { AnalyticsMapper } from '../mappers/analytics.mapper';

@Injectable()
export class AnalyticsService {
  private readonly logger = new Logger(
    AnalyticsService.name,
  );

  constructor(
    private readonly prisma: PrismaService,
    private readonly analyticsMapper: AnalyticsMapper,
  ) {}

  async findAll(
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ): Promise<
    PaginatedResponseDto<AnalyticsResponseDto>
  > {
    const {
      page,
      limit,
      search,
      platform,
      level,
      campaignId,
      adSetId,
      adId,
      creativeId,
      startDate,
      endDate,
      sortBy,
      sortOrder,
    } = query;

    const where = this.buildWhereClause({
      organizationId: currentUser.organizationId,
      search,
      platform,
      level,
      campaignId,
      adSetId,
      adId,
      creativeId,
      startDate,
      endDate,
    });

    const safeSortBy =
      this.ensureValidSortField(sortBy);

    const skip = (page - 1) * limit;

    const [snapshots, total] =
      await this.prisma.$transaction([
        this.prisma.analyticsSnapshot.findMany({
          where,
          skip,
          take: limit,
          orderBy: {
            [safeSortBy]: sortOrder,
          },
          include: ANALYTICS_INCLUDE,
        }),

        this.prisma.analyticsSnapshot.count({
          where,
        }),
      ]);

    this.logger.debug({
      message: 'Analytics retrieved.',
      organizationId:
        currentUser.organizationId,
      page,
      limit,
      total,
    });

    return {
      data: snapshots.map((snapshot) =>
        this.analyticsMapper.toResponse(
          snapshot,
        ),
      ),

      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasNextPage:
          page * limit < total,
        hasPreviousPage: page > 1,
      },
    };
  }
    async findOne(
    id: string,
    currentUser: JwtPayload,
  ): Promise<AnalyticsResponseDto> {
    const snapshot =
      await this.prisma.analyticsSnapshot.findFirst({
        where: {
          id,
          organizationId: currentUser.organizationId,
        },
        include: ANALYTICS_INCLUDE,
      });

    if (!snapshot) {
      throw new NotFoundException(
        'Analytics snapshot not found.',
      );
    }

    return this.analyticsMapper.toResponse(
      snapshot,
    );
  }

  async getSummary(
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ) {
    const where = this.buildWhereClause({
      organizationId: currentUser.organizationId,
      search: query.search,
      platform: query.platform,
      level: query.level,
      campaignId: query.campaignId,
      adSetId: query.adSetId,
      adId: query.adId,
      creativeId: query.creativeId,
      startDate: query.startDate,
      endDate: query.endDate,
    });

    const result =
      await this.prisma.analyticsSnapshot.aggregate({
        where,

        _sum: {
          impressions: true,
          reach: true,
          clicks: true,
          linkClicks: true,
          spend: true,
          conversions: true,
          conversionValue: true,
          revenue: true,
          videoViews: true,
        },

        _avg: {
          ctr: true,
          cpc: true,
          cpm: true,
          roas: true,
        },

        _count: {
          id: true,
        },
      });

    return {
      totalSnapshots: result._count.id,

      impressions:
        result._sum.impressions ?? 0,

      reach:
        result._sum.reach ?? 0,

      clicks:
        result._sum.clicks ?? 0,

      linkClicks:
        result._sum.linkClicks ?? 0,

      spend: this.decimalToNumber(
        result._sum.spend,
      ),

      conversions: this.decimalToNumber(
        result._sum.conversions,
      ),

      conversionValue:
        this.decimalToNumber(
          result._sum.conversionValue,
        ),

      revenue: this.decimalToNumber(
        result._sum.revenue,
      ),

      videoViews:
        result._sum.videoViews ?? 0,

      ctr: this.decimalToNullableNumber(
        result._avg.ctr,
      ),

      cpc: this.decimalToNullableNumber(
        result._avg.cpc,
      ),

      cpm: this.decimalToNullableNumber(
        result._avg.cpm,
      ),

      roas: this.decimalToNullableNumber(
        result._avg.roas,
      ),
    };
  }
    async getTimeSeries(
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ) {
    const where = this.buildWhereClause({
      organizationId: currentUser.organizationId,
      search: query.search,
      platform: query.platform,
      level: query.level,
      campaignId: query.campaignId,
      adSetId: query.adSetId,
      adId: query.adId,
      creativeId: query.creativeId,
      startDate: query.startDate,
      endDate: query.endDate,
    });

    const snapshots =
      await this.prisma.analyticsSnapshot.findMany({
        where,
        orderBy: {
          snapshotDate: 'asc',
        },
      });

    const series = new Map<
      string,
      {
        date: string;
        impressions: number;
        clicks: number;
        spend: number;
        revenue: number;
        conversions: number;
      }
    >();

    for (const snapshot of snapshots) {
      const date = snapshot.snapshotDate
        .toISOString()
        .split('T')[0];

      if (!series.has(date)) {
        series.set(date, {
          date,
          impressions: 0,
          clicks: 0,
          spend: 0,
          revenue: 0,
          conversions: 0,
        });
      }

      const row = series.get(date)!;

      row.impressions += snapshot.impressions;
      row.clicks += snapshot.clicks;

      row.spend += Number(snapshot.spend);

      row.revenue += Number(snapshot.revenue ?? 0);

      row.conversions += Number(
        snapshot.conversions ?? 0,
      );
    }

    return [...series.values()];
  }

  async getBreakdownByCampaign(
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ) {
    const where = this.buildWhereClause({
      organizationId: currentUser.organizationId,
      search: query.search,
      platform: query.platform,
      level: query.level,
      campaignId: query.campaignId,
      adSetId: query.adSetId,
      adId: query.adId,
      creativeId: query.creativeId,
      startDate: query.startDate,
      endDate: query.endDate,
    });

    const snapshots =
      await this.prisma.analyticsSnapshot.findMany({
        where,
        include: {
          campaign: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

    const campaignMap = new Map<
      string,
      {
        id: string;
        name: string;
        impressions: number;
        clicks: number;
        spend: number;
        revenue: number;
        conversions: number;
      }
    >();

    for (const snapshot of snapshots) {
      if (!snapshot.campaign) {
        continue;
      }

      const key = snapshot.campaign.id;

      if (!campaignMap.has(key)) {
        campaignMap.set(key, {
          id: key,
          name: snapshot.campaign.name,
          impressions: 0,
          clicks: 0,
          spend: 0,
          revenue: 0,
          conversions: 0,
        });
      }

      const campaign = campaignMap.get(key)!;

      campaign.impressions += snapshot.impressions;

      campaign.clicks += snapshot.clicks;

      campaign.spend += Number(snapshot.spend);

      campaign.revenue += Number(
        snapshot.revenue ?? 0,
      );

      campaign.conversions += Number(
        snapshot.conversions ?? 0,
      );
    }

    return [...campaignMap.values()].sort(
      (a, b) => b.spend - a.spend,
    );
  }
    async getBreakdownByAdSet(
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ) {
    return this.getBreakdown(
      'adSet',
      query,
      currentUser,
    );
  }

  async getBreakdownByAd(
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ) {
    return this.getBreakdown(
      'ad',
      query,
      currentUser,
    );
  }

  async getBreakdownByCreative(
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ) {
    return this.getBreakdown(
      'creative',
      query,
      currentUser,
    );
  }

  private async getBreakdown(
    relation: 'campaign' | 'adSet' | 'ad' | 'creative',
    query: AnalyticsQueryDto,
    currentUser: JwtPayload,
  ) {
    const where = this.buildWhereClause({
      organizationId: currentUser.organizationId,
      search: query.search,
      platform: query.platform,
      level: query.level,
      campaignId: query.campaignId,
      adSetId: query.adSetId,
      adId: query.adId,
      creativeId: query.creativeId,
      startDate: query.startDate,
      endDate: query.endDate,
    });

    const snapshots =
      await this.prisma.analyticsSnapshot.findMany({
        where,
        include: {
          [relation]: {
            select: {
              id: true,
              name: true,
            },
          },
        } as Prisma.AnalyticsSnapshotInclude,
      });

    const breakdown = new Map<
      string,
      {
        id: string;
        name: string;
        impressions: number;
        clicks: number;
        spend: number;
        revenue: number;
        conversions: number;
        snapshots: number;
      }
    >();

    for (const snapshot of snapshots) {
      const entity = snapshot[
        relation
      ] as { id: string; name: string } | null;

      if (!entity) {
        continue;
      }

      if (!breakdown.has(entity.id)) {
        breakdown.set(entity.id, {
          id: entity.id,
          name: entity.name,
          impressions: 0,
          clicks: 0,
          spend: 0,
          revenue: 0,
          conversions: 0,
          snapshots: 0,
        });
      }

      const row = breakdown.get(entity.id)!;

      row.snapshots++;

      row.impressions += snapshot.impressions;

      row.clicks += snapshot.clicks;

      row.spend += Number(snapshot.spend);

      row.revenue += Number(
        snapshot.revenue ?? 0,
      );

      row.conversions += Number(
        snapshot.conversions ?? 0,
      );
    }

    return [...breakdown.values()].sort(
      (a, b) => b.spend - a.spend,
    );
  }
    private buildWhereClause(filters: {
    organizationId: string;
    search?: string;
    platform?: PlatformType;
    level?: AnalyticsLevel;
    campaignId?: string;
    adSetId?: string;
    adId?: string;
    creativeId?: string;
    startDate?: string;
    endDate?: string;
  }): Prisma.AnalyticsSnapshotWhereInput {
    const where: Prisma.AnalyticsSnapshotWhereInput = {
      organizationId: filters.organizationId,
    };

    if (filters.platform) {
      where.platform = filters.platform;
    }

    if (filters.level) {
      where.level = filters.level;
    }

    if (filters.campaignId) {
      where.campaignId = filters.campaignId;
    }

    if (filters.adSetId) {
      where.adSetId = filters.adSetId;
    }

    if (filters.adId) {
      where.adId = filters.adId;
    }

    if (filters.creativeId) {
      where.creativeId = filters.creativeId;
    }

    if (filters.startDate || filters.endDate) {
      where.snapshotDate = this.buildDateFilter(
        filters.startDate,
        filters.endDate,
      );
    }

    if (filters.search) {
      where.OR = [
        {
          campaign: {
            is: {
              name: {
                contains: filters.search,
                mode: 'insensitive',
              },
            },
          },
        },
        {
          adSet: {
            is: {
              name: {
                contains: filters.search,
                mode: 'insensitive',
              },
            },
          },
        },
        {
          ad: {
            is: {
              name: {
                contains: filters.search,
                mode: 'insensitive',
              },
            },
          },
        },
        {
          creative: {
            is: {
              name: {
                contains: filters.search,
                mode: 'insensitive',
              },
            },
          },
        },
      ];
    }

    return where;
  }

  private buildDateFilter(
    startDate?: string,
    endDate?: string,
  ): Prisma.DateTimeFilter {
    const filter: Prisma.DateTimeFilter = {};

    if (startDate) {
      filter.gte = new Date(startDate);
    }

    if (endDate) {
      const date = new Date(endDate);

      date.setHours(23, 59, 59, 999);

      filter.lte = date;
    }

    return filter;
  }

  private ensureValidSortField(
    sortBy?: string,
  ): AnalyticsSortField {
    if (
      sortBy &&
      ANALYTICS_SORT_FIELDS.includes(
        sortBy as AnalyticsSortField,
      )
    ) {
      return sortBy as AnalyticsSortField;
    }

    return DEFAULT_SORT_BY;
  }
    private decimalToNumber(
    value:
      | Prisma.Decimal
      | number
      | null
      | undefined,
  ): number {
    if (value === null || value === undefined) {
      return 0;
    }

    if (typeof value === 'number') {
      return value;
    }

    return value.toNumber();
  }

  private decimalToNullableNumber(
    value:
      | Prisma.Decimal
      | number
      | null
      | undefined,
  ): number | null {
    if (value === null || value === undefined) {
      return null;
    }

    if (typeof value === 'number') {
      return value;
    }

    return value.toNumber();
  }

  private validateDateRange(
    startDate?: string,
    endDate?: string,
  ): void {
    if (!startDate || !endDate) {
      return;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);

    if (
      Number.isNaN(start.getTime()) ||
      Number.isNaN(end.getTime())
    ) {
      throw new Error(
        'Invalid date range.',
      );
    }

    if (start > end) {
      throw new Error(
        'Start date cannot be after end date.',
      );
    }
  }
}
