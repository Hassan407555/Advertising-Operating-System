import { PlatformType } from '@prisma/client';

export const SHOPIFY_PLATFORM = PlatformType.SHOPIFY;

export const SHOPIFY_API_VERSION = '2025-10';

export const SHOPIFY_AUTH_SCOPES = [
  'read_products',
] as const;

export const SHOPIFY_AUTH_PATH = '/admin/oauth/authorize';

export const SHOPIFY_ACCESS_TOKEN_PATH =
  '/admin/oauth/access_token';

export const SHOPIFY_GRAPHQL_PATH = (
  version = SHOPIFY_API_VERSION,
) => `/admin/api/${version}/graphql.json`;

export const SHOPIFY_REST_PATH = (
  version = SHOPIFY_API_VERSION,
) => `/admin/api/${version}`;

export const SHOPIFY_DEFAULT_SYNC_LIMIT = 250;