import {
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Query,
} from '@nestjs/common';

import { ShopifyOAuthService } from './services/shopify-oauth.service';
import { ShopifyProductsService } from './services/shopify-products.service';
import { ShopifyStoreService } from './services/shopify-store.service';

@Controller('shopify')
export class ShopifyController {
  constructor(
    private readonly shopifyOAuthService: ShopifyOAuthService,
    private readonly shopifyStoreService: ShopifyStoreService,
    private readonly shopifyProductsService: ShopifyProductsService,
  ) {}

  @Post('connect')
  connect() {
    return this.shopifyOAuthService.connect();
  }

  @Get('callback')
  callback(@Query() query: Record<string, any>) {
    return this.shopifyOAuthService.callback(query);
  }

  @Get('store')
  getStore() {
    return this.shopifyStoreService.getStore();
  }

  @Delete('disconnect')
  disconnect() {
    return this.shopifyOAuthService.disconnect();
  }

  @Post('products/sync')
  syncProducts() {
    return this.shopifyProductsService.syncProducts();
  }

  @Get('products')
  getProducts() {
    return this.shopifyProductsService.getProducts();
  }

  @Get('products/:id')
  getProduct(@Param('id') id: string) {
    return this.shopifyProductsService.getProduct(id);
  }
}